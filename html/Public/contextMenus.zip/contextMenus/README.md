### 套用至 google
[到 google 延伸模組](chrome://extensions/)

### 開啟開發人員模式
![alt text](./圖片/image.png)

### 載入未封裝項目
![alt text](./圖片/image-1.png)

### 開啟到資料夾下直接開啟資料夾
![alt text](./圖片/image-2.png)

### 匯入成功
![alt text](./圖片/image-3.png)


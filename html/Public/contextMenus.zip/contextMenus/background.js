﻿chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete" && tab.url.includes("cps.youbike2.com")) {

        chrome.cookies.getAll({ domain: "cps.youbike2.com" }, (cookies) => {
            let cookiesToken = cookies.map(cookie => `${cookie.name}=${cookie.value}`).join("; Expires=Thu, 13 Mar 2025 09:18:44 GMT;");
            console.log("取得的 Cookie:", cookiesToken);

            let cookieValue = cookiesToken || "";

            // console.log(cookieValue);

            // 找到當前活動的分頁，發送訊息到 `content.js`
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs.length > 0) {
                    chrome.tabs.sendMessage(tabs[0].id, { action: "sendCookies", cookies: cookieValue });
                }
            });
        });
    }
});

// chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
//     if (message.action === "copyed") {

//     }
// });

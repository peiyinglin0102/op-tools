﻿let cookies = "";
let oldTable = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "sendCookies") {
        cookies = message.cookies;
    }
});

// 監聽網頁變化
const observer = new MutationObserver(() => {
    const table = document.querySelector("table.table-bordered"); // 找到網頁上的 table
    if (oldTable == table) {
        // console.warn("相等");
    } else {
        // console.warn("不相等 addAllToTable 執行");

        if (table) {
            observer.disconnect(); // 找到 table 後就停止監聽，避免重複執行
            addAllToTable(table); // 在 table 加入按鈕

            oldTable = document.querySelector("table.table-bordered");
        }
        oldTable = table;
    }
});

observer.observe(document.body, { childList: true, subtree: true });

function addAllToTable(table) {
    const thead = table.querySelector("thead");
    if (!thead) {
        return 0;
    }
    const theadTh = thead.querySelectorAll("th");
    if (!theadTh) {
        return 0;
    }
    const searchTexts = ["外觀車號", "訂單號", "外觀卡號", "借車場站", "斷電還車", "還車場站", "狀態", "借車時間", "還車時間", "卡別"];
    const indexes = searchTexts.map(text =>
        Array.from(theadTh).findIndex(th => th.textContent.includes(text))
    );

    if (!table.querySelector("tbody#member-transactions")) {
        return 0;
    }
    const tbodyTr = table.querySelector("tbody#member-transactions").querySelectorAll("tr"); // 找到所有表格列

    tbodyTr.forEach((tr) => {
        let trTd = tr.querySelectorAll("td");

        const asset_no = trTd[indexes[0]];
        const order_no = trTd[indexes[1]];
        const card_no = trTd[indexes[2]];
        const rent_station = trTd[indexes[3]];
        const return_when_power_off = trTd[indexes[4]];
        const return_station = trTd[indexes[5]];
        const status = trTd[indexes[6]];
        const rent_time = trTd[indexes[7]];
        const return_time = trTd[indexes[8]];
        const card_type = trTd[indexes[9]];

        // 借車場站 修改 value
        changeStationText(rent_station);
        changeStationText(return_station);
        // 斷電還車 修改 value
        changePowerText(return_when_power_off);
        changeStatusText(status);


        let allAddButton = document.createElement("span");
        addChangeShowButton(allAddButton);

        let allFunctionButton = document.createElement("span");
        allFunctionButton.style.display = 'none';

        addOrderNoButton(asset_no, order_no, allFunctionButton);
        addCardNoToIc(card_type.textContent, card_no.textContent, allFunctionButton);
        addCardEditButton(card_no, allFunctionButton);
        addFindAssetNoErrorButton(asset_no, rent_time, return_time, allFunctionButton);

        allAddButton.appendChild(allFunctionButton);
        tr.appendChild(allAddButton);

        card_no.style.color = " #0378df";

        addRadioButtton(rent_time);
    });

    observer.observe(document.body, { childList: true, subtree: true });
}

function copyClipboard(order_no, showCopyStatus) {
    navigator.clipboard.writeText(order_no).then(() => {
        if (showCopyStatus) {
            showText("已複製到剪貼簿 (*≧∀≦*)♡");
        }
    });
}

function showText(text) {
    let tooltip = document.createElement("div");
    tooltip.textContent = text;
    tooltip.style.position = "fixed";
    tooltip.style.bottom = "20px";
    tooltip.style.right = "20px";
    tooltip.style.background = "rgba(0, 0, 0, 0.7)";
    tooltip.style.color = "#fff";
    tooltip.style.padding = "15px 25px"; // 加大長寬
    tooltip.style.borderRadius = "8px"; // 圓角加大
    tooltip.style.fontSize = "16px"; // 字體稍微加大
    tooltip.style.zIndex = "9999";
    tooltip.style.transition = "opacity 0.3s";

    document.body.appendChild(tooltip);

    // 1.5 秒後自動消失
    setTimeout(() => {
        tooltip.style.opacity = "0";
        setTimeout(() => tooltip.remove(), 300); // 過渡動畫後刪除
    }, 1500);
}

function addChangeShowButton(parent) {
    let newButton = document.createElement("button");
    newButton.textContent = "開啟/關閉按鈕"; // 設定按鈕文字
    // newButton.style.padding = "4px 10px"; // 內邊距，較小的尺寸
    newButton.style.fontSize = "12px"; // 文字大小更精緻
    newButton.style.color = "#fff"; // 文字顏色
    newButton.style.background = " #2C3E50"; // 藍色背景
    newButton.style.border = "1px solid #0056b3"; // 深色邊框
    newButton.style.borderRadius = "3px"; // 輕微圓角
    newButton.style.cursor = "pointer"; // 滑鼠變手型
    newButton.style.transition = "background 0.2s, transform 0.1s"; // 平滑動畫

    // 懸停時變深色
    newButton.addEventListener("mouseover", () => {
        newButton.style.background = " #243647";
    });

    // 點擊時微縮小
    newButton.addEventListener("mousedown", () => {
        newButton.style.transform = "scale(0.95)";
    });

    // 釋放時恢復
    newButton.addEventListener("mouseup", () => {
        newButton.style.transform = "scale(1)";
    });

    // 滑鼠移開時恢復原樣
    newButton.addEventListener("mouseout", () => {
        newButton.style.background = " #2C3E50";
    });

    newButton.addEventListener("click", () => {
        const next = newButton.nextElementSibling;
        if (next.style.display === 'none') {
            next.style.display = 'inline'; // 顯示
        } else {
            next.style.display = 'none';   // 隱藏
        }
    });

    parent.appendChild(newButton);
}

function addOrderNoButton(asset_no, order_no, parent) {
    let newButton = document.createElement("button");
    newButton.textContent = "搜尋交易紀錄"; // 設定按鈕文字
    // newButton.style.padding = "4px 10px"; // 內邊距，較小的尺寸
    newButton.style.fontSize = "12px"; // 文字大小更精緻
    newButton.style.color = "#fff"; // 文字顏色
    newButton.style.background = "#007BFF"; // 藍色背景
    newButton.style.border = "1px solid #0056b3"; // 深色邊框
    newButton.style.borderRadius = "3px"; // 輕微圓角
    newButton.style.cursor = "pointer"; // 滑鼠變手型
    newButton.style.transition = "background 0.2s, transform 0.1s"; // 平滑動畫

    // 懸停時變深色
    newButton.addEventListener("mouseover", () => {
        newButton.style.background = "#0056b3";
    });

    // 點擊時微縮小
    newButton.addEventListener("mousedown", () => {
        newButton.style.transform = "scale(0.95)";
    });

    // 釋放時恢復
    newButton.addEventListener("mouseup", () => {
        newButton.style.transform = "scale(1)";
    });

    // 滑鼠移開時恢復原樣
    newButton.addEventListener("mouseout", () => {
        newButton.style.background = "#007BFF";
    });

    newButton.addEventListener("click", () => {
        copyClipboard(order_no.textContent, 0);

        rent_time_st = formatDate(3);
        rent_time_ed = formatDate(0);

        asset_no_forGet = asset_no.textContent;

        const url = `https://cps.youbike2.com/DataSearch/Transactions/Search?province_id=&city_id=&card_type_id=&bike_type_id=&rate_type_id=&rent_time_st=${rent_time_st}&rent_time_ed=${rent_time_ed}&rent_pillar=&return_time_st=&return_time_ed=&return_pillar=&charge_time_st=&charge_time_ed=&order_no=&card_no=&asset_no=${asset_no_forGet}&account=&remark=&status=&return_when_power_off=&adjusted_amount=&discount=&usage_minute_st=&usage_minute_ed=&receivable_st=&receivable_ed=&per_page=15&page=1`;

        fetchCps(url, order_no.textContent);
    });

    parent.appendChild(newButton);
}

function addCardNoToIc(card_type, card_no, parent) {
    let newButton = document.createElement("button");
    newButton.textContent = "搜尋 card_ic";

    // 橘色主題樣式
    newButton.style.fontSize = "12px";
    newButton.style.color = " #ffffff";
    newButton.style.background = "#FF8C00"; // 橘色背景
    newButton.style.border = "1px solid #cc7000"; // 深橘邊框
    newButton.style.borderRadius = "3px";
    newButton.style.cursor = "pointer";
    newButton.style.transition = "background 0.2s, transform 0.1s";

    // 懸停時變深橘
    newButton.addEventListener("mouseover", () => {
        newButton.style.background = " #cc7000";
    });

    // 點擊時微縮小
    newButton.addEventListener("mousedown", () => {
        newButton.style.transform = "scale(0.95)";
    });

    // 釋放時恢復
    newButton.addEventListener("mouseup", () => {
        newButton.style.transform = "scale(1)";
    });

    // 滑鼠移開時恢復原始背景
    newButton.addEventListener("mouseout", () => {
        newButton.style.background = " #FF8C00";
    });

    newButton.addEventListener("click", () => {
        const card_type_number = card_type.match(/\d/g);
        const url = `https://cps.youbike2.com/DataSearch/CardIdNoSearch/Search?card_type=${card_type_number}&card_no=${card_no}&card_id=`

        fetchCpsCardIc(url);
    });

    parent.appendChild(newButton);
}

function addCardEditButton(card_no, parent) {
    let newButton = document.createElement("button");
    newButton.textContent = "搜尋卡片資料"; // 設定按鈕文字
    // newButton.style.padding = "4px 10px"; // 內邊距，較小的尺寸
    newButton.style.fontSize = "12px"; // 文字大小更精緻
    newButton.style.color = "#fff"; // 文字顏色
    newButton.style.background = "#28a745"; // 綠色背景
    newButton.style.border = "1px solid #1e7e34"; // 深綠邊框
    newButton.style.borderRadius = "3px"; // 輕微圓角
    newButton.style.cursor = "pointer"; // 滑鼠變手型
    newButton.style.transition = "background 0.2s, transform 0.1s"; // 平滑動畫

    // 懸停時變深色
    newButton.addEventListener("mouseover", () => {
        newButton.style.background = " #1e7e34";
    });

    // 點擊時微縮小
    newButton.addEventListener("mousedown", () => {
        newButton.style.transform = "scale(0.95)";
    });

    // 釋放時恢復
    newButton.addEventListener("mouseup", () => {
        newButton.style.transform = "scale(1)";
    });

    // 滑鼠移開時恢復原樣
    newButton.addEventListener("mouseout", () => {
        newButton.style.background = " #28a745";
    });

    newButton.addEventListener("click", () => {
        card_no_forGet = card_no.textContent;

        const url = `https://cps.youbike2.com/DataMaintain/Cards/${card_no_forGet}/Edit`;
        window.open(url, "_blank");
    });

    parent.appendChild(newButton);
}

function addFindAssetNoErrorButton(asset_no, rent_time, return_time, parent) {
    let newButton = document.createElement("button");
    newButton.textContent = "找尋車機紀錄";

    // 美觀的黃色按鈕樣式
    newButton.style.fontSize = "12px";                 // 精緻文字
    newButton.style.color = " #ffffff";                    // 深色文字
    newButton.style.background = " #ffcc00";            // 明亮黃
    newButton.style.border = "1px solid #e6b800";      // 深黃邊框
    newButton.style.borderRadius = "3px";              // 稍微圓角
    newButton.style.cursor = "pointer";                // 滑鼠手勢
    newButton.style.transition = "background 0.2s, transform 0.1s"; // 平滑動畫

    // hover 效果（需搭配 JS 加入事件）
    newButton.addEventListener("mouseenter", () => {
        newButton.style.background = " #ffd633";
    });
    newButton.addEventListener("mouseleave", () => {
        newButton.style.background = " #ffcc00";
    });

    newButton.addEventListener("click", () => {
        card_no_forGet = card_no.textContent;

        const url = `https://cps.youbike2.com/DataSearch/WarningSearch`;
        const newWindow = window.open(url, "_blank");

        newWindow.onload = () => {

            const assetNoElement = newWindow.document.getElementById("asset_no");
            const timeStElement = newWindow.document.getElementById("time_st");
            const timeEdElement = newWindow.document.getElementById("time_ed");

            if (!assetNoElement || !timeStElement || !timeEdElement) {
                newWindow.console.log("timeStElement 找不到");
                console.log("timeStElement 找不到");
                return;
            }

            const assetNoContent = asset_no.textContent;  // 這邊是原本頁面
            const rentTimeContent = subtractHoursFromTime(rent_time.textContent, "sub", 1);
            const returnTimeContent = subtractHoursFromTime(return_time.textContent, "add", 1);

            assetNoElement.value = assetNoContent;
            timeStElement.value = rentTimeContent;
            timeEdElement.value = returnTimeContent;

            newWindow.document.getElementById("search-btn").click();
        };
    });

    parent.appendChild(newButton);
}

async function fetchCps(url, order_no) {
    const options = {
        method: "GET",
        credentials: "same-origin",
        headers: {
            Cookie: cookies,
        },
    };

    const request = new Request(url, options);

    fetch(request)
        .then(response => response.text())
        .then(data => {
            const tbodyMatch = data.match(/<tbody[^>]*>([\s\S]*?)<tr>([\s\S]*?)<\\\/tr>([\s\S]*?)<\\\/tbody>[\s\S]*?/i);

            console.log("查找到的資料", tbodyMatch);

            if (tbodyMatch == null) {

                throw new Error("沒找到東西");
            } else {
                const tbodyMatchValue = tbodyMatch[2];

                const tdMatches = [...tbodyMatchValue.matchAll(/<td[^>]*>([\s\S]*?)<\\\/td>/gi)];

                console.log("tdMatches", tdMatches);
                const trValue = tdMatches[33][1]
                // console.log("trValue", trValue);
                if (!trValue) {

                    throw new Error("trValue 錯誤");
                }
                if (trValue == order_no) {
                    showText("該車輛尚無下一筆調度或借車紀錄，因此尚無法協助回補，謝謝");
                    return;
                }
            }
            showText("不是最後一筆，可以回補");
        })
        .catch(error => {
            console.error("❌ 錯誤:", error);
            alert("請求失敗，請重整畫面後再次嘗試");
        });
}

async function fetchCpsCardIc(url) {
    const options = {
        method: "GET",
        headers: {
            Cookie: cookies,
        },
    };

    const request = new Request(url, options);

    fetch(request)
        .then(response => response.text())
        .then(data => {
            const card_data = JSON.parse(data);

            copyClipboard(card_data.retVal[0].card_ic, 1);
        })
        .catch(error => {
            console.error("❌ 錯誤:", error);
            alert("請求失敗，請重整畫面再次嘗試");
        });
}

function formatDate(offsetDays = 0) {
    let date = new Date();
    date.setDate(date.getDate() - offsetDays);

    let yyyy = date.getFullYear();
    let mm = String(date.getMonth() + 1).padStart(2, '0');
    let dd = String(date.getDate()).padStart(2, '0');
    let hh = '23', mi = '59', ss = '59';

    return `${yyyy}-${mm}-${dd}%20${hh}%3A${mi}%3A${ss}`;
}

function changeStationText(rent_station) {
    const rent_station_text = rent_station.textContent.trimStart();
    let stationTextChangedValue = matchText(rent_station_text, /^500([0-3])/, '北區', 'red', /\d*/);
    if (!stationTextChangedValue) {
        stationTextChangedValue = matchText(rent_station_text, /^500([4-7])/, '中區', 'blue', /\d*/);
        if (!stationTextChangedValue) {
            stationTextChangedValue = matchText(rent_station_text, /^501([0-5])/, '南區', ' #2E8B57', /\d*/);
        }
    }
    if (stationTextChangedValue) {
        rent_station.innerHTML = stationTextChangedValue;
    }
}

function matchText(textContent, match, outPutContent, textColor, matchText) {
    const textContentMatch = textContent.match(match);

    if (!textContentMatch) {
        return 0;
    }

    // const matchContent = textContent.replace(matchText, `<span style=\"color:${textColor};\" title=\"${textContent}\">${outPutContent}</span>`);
    const matchContent = textContent.replace(matchText, `<span style="color:${textColor};" title="${textContent}" onclick="(function(){navigator.clipboard.writeText('${textContent}').then();})();">${outPutContent}</span>`);

    return matchContent;
}

function changePowerText(returnWhenPowerOff) {
    let matchTextRet = matchText(returnWhenPowerOff.textContent, /是/, '是', 'red', /是/);
    if (matchTextRet) {
        // matchTextRet = "否";
        returnWhenPowerOff.innerHTML = matchTextRet;
    }
}

function changeStatusText(returnWhenPowerOff) {
    let matchTextRet = matchText(returnWhenPowerOff.textContent, /借車失敗/, '借車失敗', 'red', /借車失敗/);
    if (matchTextRet) {
        returnWhenPowerOff.innerHTML = matchTextRet;
    }
}

function addRadioButtton(rent_time) {
    let newRadio = document.createElement("input");
    newRadio.type = "checkbox";
    newRadio.style.display = "none"; // 你看不見我
    // radio.name = 'myRadioGroup'; // 如果需要互斥
    const parent = rent_time.closest('tr')

    newRadio.addEventListener("click", () => {
        if (newRadio.checked) {
            parent.style.backgroundColor = ' #dff0d8'; // 淺綠色
        } else {
            parent.style.backgroundColor = '';
        }
    });

    rent_time.appendChild(newRadio);

    rent_time.addEventListener("click", () => {
        newRadio.click();
    })
}

function subtractHoursFromTime(datetimeStr, mode = "add", hours = 1) {
    const date = new Date(datetimeStr.replace(' ', 'T'));

    if (isNaN(date)) {
        throw new Error("❌ 無效的時間格式，請使用 'YYYY-MM-DD HH:mm:ss'");
    }

    if (mode == "add") {
        date.setHours(date.getHours() + hours);
    } else {
        date.setHours(date.getHours() - hours);
    }

    const pad = (n) => n.toString().padStart(2, '0');
    const formatted = `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;

    return formatted;
}
